<?php
return array(
  'crypto_key' => 'jiAWJAu1oK6AtwkdxYWHQ60Q',
  'crypto_iv' => 'I04BRwzDE5Q4D8EbvYNAQSk4',
  'crypto_hmac' => 'N2MGiE2uExgc3S4mjEg9kIKw',
);
