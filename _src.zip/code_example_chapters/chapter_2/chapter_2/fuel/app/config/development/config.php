<?php

return array(
    'profiling'  => true,
);
