The code of chapter 1 is in the chapter_1 directory. You can copy it in the root directory of
your webserver or you can use virtual hosts.

You will need to change the database configuration and create the necessary tables. You can
use the project's migrations files, but if you don't want to use oil or need some test
data, you can execute the SQL code inside the install.sql file.