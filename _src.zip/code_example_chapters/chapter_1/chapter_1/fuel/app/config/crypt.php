<?php
return array(
  'crypto_key' => 'oQ0r7YATsy8IzA4em8NFgTSE',
  'crypto_iv' => 'Zm0y-4bDMGbs4zcYUcsMUMMo',
  'crypto_hmac' => 'XXAfSwgC8nqgeK0lgMxjwg9w',
);
