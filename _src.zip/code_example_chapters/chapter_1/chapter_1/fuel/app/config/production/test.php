<?php
return array(
    'complex_value' => array(
        'prod' => true,
    ),
    'this_is_the_root_config_file' => false, 
    'this_is_the_prod_config_file' => true,
);
