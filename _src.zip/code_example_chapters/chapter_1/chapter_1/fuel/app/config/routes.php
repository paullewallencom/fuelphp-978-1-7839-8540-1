<?php
return array(
	'_root_'  => 'monkey/index',  // The default route
);