<?php
return array(
    'this_is_the_dev_config_file' => true,
);
