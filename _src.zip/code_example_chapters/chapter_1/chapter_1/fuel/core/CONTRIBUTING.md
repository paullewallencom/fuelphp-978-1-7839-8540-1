Please read the project contibuting guidelines before creating an issue of sending in a pull request:

https://github.com/fuel/fuel/wiki/Contributing
